from django.db import models


class Opportunity(models.Model):
    SCALE_CHOICES = [
        ('russia', 'Всероссийский'),
        ('international', 'Международный'),
    ]
    TYPE_CHOICES = [
        ('internship', 'Стажировка'),
        ('grant', 'Грант'),
        ('hackathon', 'Хакатон'),
        ('conference', 'Конференция'),
        ('it-event', 'IT-мероприятие'),
    ]

    title = models.CharField('Название', max_length=255)
    company = models.CharField('Компания/организатор', max_length=255)
    city = models.CharField('Город', max_length=100)
    region = models.CharField('Регион', max_length=100)
    scale = models.CharField('Масштаб', max_length=20, choices=SCALE_CHOICES, default='russia')
    type = models.CharField('Тип', max_length=20, choices=TYPE_CHOICES)
    direction = models.CharField('Направление', max_length=100)
    age_min = models.PositiveIntegerField('Возраст от')
    age_max = models.PositiveIntegerField('Возраст до')
    grant_amount = models.PositiveIntegerField('Сумма гранта/стипендии, ₽', default=0)
    deadline = models.DateField('Дедлайн')
    tag = models.CharField('Тег-категория', max_length=100)
    is_active = models.BooleanField('Активно', default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Возможность'
        verbose_name_plural = 'Возможности'
        ordering = ['-deadline']

    def __str__(self):
        return f'{self.title} — {self.company}'
