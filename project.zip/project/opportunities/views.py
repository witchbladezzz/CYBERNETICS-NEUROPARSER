from rest_framework import viewsets, status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.db.models import Q
from .models import Opportunity
from .serializers import OpportunitySerializer


class OpportunityViewSet(viewsets.ReadOnlyModelViewSet):
    """Список возможностей с фильтрацией через query-параметры."""
    serializer_class = OpportunitySerializer

    def get_queryset(self):
        qs = Opportunity.objects.filter(is_active=True)
        params = self.request.query_params

        scale = params.get('scale')
        type_ = params.get('type')
        direction = params.get('direction')
        region = params.get('region')
        age_from = params.get('age_from')
        age_to = params.get('age_to')
        grant_min = params.get('grant_min')

        if scale and scale != 'all':
            qs = qs.filter(scale=scale)
        if type_ and type_ != 'all':
            qs = qs.filter(type=type_)
        if direction and direction != 'all':
            qs = qs.filter(direction=direction)
        if region and region != 'all':
            qs = qs.filter(region=region)
        if age_from and age_from.isdigit():
            # диапазон участника должен пересекаться с диапазоном мероприятия
            qs = qs.filter(age_max__gte=int(age_from))
        if age_to and age_to.isdigit():
            qs = qs.filter(age_min__lte=int(age_to))
        if grant_min and grant_min.isdigit():
            qs = qs.filter(grant_amount__gte=int(grant_min))

        return qs


@api_view(['GET'])
def regions_list(request):
    """Список регионов, опционально отфильтрованный по масштабу."""
    scale = request.query_params.get('scale', 'all')
    qs = Opportunity.objects.filter(is_active=True)
    if scale and scale != 'all':
        qs = qs.filter(scale=scale)
    regions = sorted(qs.values_list('region', flat=True).distinct())
    return Response(regions)


@api_view(['GET'])
def directions_list(request):
    """Список всех направлений."""
    directions = sorted(
        Opportunity.objects.filter(is_active=True)
        .values_list('direction', flat=True)
        .distinct()
    )
    return Response(directions)
