from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'opportunities', views.OpportunityViewSet, basename='opportunity')

urlpatterns = [
    path('', include(router.urls)),
    path('regions/', views.regions_list, name='regions-list'),
    path('directions/', views.directions_list, name='directions-list'),
]
