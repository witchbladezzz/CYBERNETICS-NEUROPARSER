from django.core.management.base import BaseCommand
from opportunities.models import Opportunity


class Command(BaseCommand):
    help = 'Заполняет БД тестовыми возможностями'

    def handle(self, *args, **options):
        if Opportunity.objects.exists():
            self.stdout.write(self.style.WARNING('БД уже заполнена. Очищаю...'))
            Opportunity.objects.all().delete()

        data = [
            dict(title="Стажер Frontend-разработчик", company="Сбер", city="Москва",
                 region="Москва", scale="russia", type="internship", direction="Frontend",
                 age_min=18, age_max=30, grant_amount=80000, deadline="2026-07-20", tag="Разработка"),
            dict(title="Грант на развитие IT-стартапа", company="Фонд Содействия Инновациям",
                 city="Казань", region="Республика Татарстан", scale="russia", type="grant",
                 direction="Product Manager", age_min=18, age_max=35, grant_amount=500000,
                 deadline="2026-09-01", tag="Бизнес и стартапы"),
            dict(title="Стажировка в отделе UX/UI дизайна", company="Яндекс",
                 city="Удаленно", region="Москва", scale="russia", type="internship",
                 direction="UX/UI дизайн", age_min=18, age_max=28, grant_amount=60000,
                 deadline="2026-06-25", tag="Дизайн"),
            dict(title="Стипендиальная программа для аналитиков", company="Т-Банк",
                 city="Санкт-Петербург", region="Санкт-Петербург", scale="russia",
                 type="internship", direction="Data Analyst", age_min=18, age_max=25,
                 grant_amount=45000, deadline="2026-08-20", tag="Аналитика"),
            dict(title="Летняя школа по Data Science", company="МФТИ и Сбер",
                 city="Москва", region="Москва", scale="russia", type="it-event",
                 direction="Data Science / ML", age_min=16, age_max=25,
                 grant_amount=30000, deadline="2026-07-18", tag="Образование"),
            dict(title="Хакатон «Цифровой прорыв»", company="АНО «Россия — страна возможностей»",
                 city="Новосибирск", region="Новосибирская область", scale="russia",
                 type="hackathon", direction="Backend", age_min=18, age_max=35,
                 grant_amount=300000, deadline="2026-07-15", tag="Хакатон"),
            dict(title="Международная конференция AI Summit", company="AI Research Institute",
                 city="Берлин", region="Европа", scale="international", type="conference",
                 direction="Data Science / ML", age_min=21, age_max=45,
                 grant_amount=0, deadline="2026-10-01", tag="Конференция"),
            dict(title="Стажировка в отделе кибербезопасности", company="Kaspersky",
                 city="Удаленно", region="Москва", scale="russia", type="internship",
                 direction="Кибербезопасность", age_min=18, age_max=30,
                 grant_amount=70000, deadline="2026-06-25", tag="Кибербезопасность"),
            dict(title="Программа развития финансовых лидеров", company="ВТБ",
                 city="Екатеринбург", region="Свердловская область", scale="russia",
                 type="internship", direction="Бизнес-аналитика", age_min=21, age_max=32,
                 grant_amount=65000, deadline="2026-08-25", tag="Финансы"),
            dict(title="Стажер DevOps-инженер", company="Ozon",
                 city="Санкт-Петербург", region="Санкт-Петербург", scale="russia",
                 type="internship", direction="DevOps", age_min=18, age_max=28,
                 grant_amount=90000, deadline="2026-07-20", tag="IT-разработка"),
            dict(title="Грант Google for Startups Asia", company="Google",
                 city="Сингапур", region="Азия", scale="international", type="grant",
                 direction="Mobile", age_min=18, age_max=40, grant_amount=1500000,
                 deadline="2026-11-01", tag="Бизнес и стартапы"),
            dict(title="Хакатон по автоматизации тестирования", company="VK",
                 city="Москва", region="Москва", scale="russia", type="hackathon",
                 direction="QA Автоматизация", age_min=18, age_max=30,
                 grant_amount=200000, deadline="2026-06-25", tag="Тестирование"),
            dict(title="Стажировка Product Manager", company="Авито",
                 city="Удаленно", region="Москва", scale="russia", type="internship",
                 direction="Product Manager", age_min=20, age_max=30,
                 grant_amount=75000, deadline="2026-08-10", tag="Менеджмент"),
            dict(title="Конференция DevOps Days Africa", company="DevOps Institute",
                 city="Кейптаун", region="Африка", scale="international", type="conference",
                 direction="DevOps", age_min=21, age_max=50,
                 grant_amount=0, deadline="2026-09-15", tag="Конференция"),
            dict(title="Грант на научное исследование в сфере ИИ", company="РАН и АНО «ИИ»",
                 city="Новосибирск", region="Новосибирская область", scale="russia",
                 type="grant", direction="Data Science / ML", age_min=21, age_max=40,
                 grant_amount=1000000, deadline="2026-10-01", tag="Наука и ИИ"),
            dict(title="Стажировка Backend-разработчик (Go)", company="Wildberries",
                 city="Москва", region="Москва", scale="russia", type="internship",
                 direction="Backend", age_min=18, age_max=28,
                 grant_amount=85000, deadline="2026-06-25", tag="Разработка"),
        ]

        Opportunity.objects.bulk_create([Opportunity(**d) for d in data])
        self.stdout.write(self.style.SUCCESS(f'✅ Добавлено {len(data)} записей'))
