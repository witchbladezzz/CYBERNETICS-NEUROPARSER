from rest_framework import serializers
from .models import Opportunity


class OpportunitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Opportunity
        fields = [
            'id', 'title', 'company', 'city', 'region',
            'scale', 'type', 'direction',
            'age_min', 'age_max', 'grant_amount',
            'deadline', 'tag', 'is_active',
        ]
